function full() {
    window.open('index.html', '', 'fullscreen=yes, scrollbars=no, width=100%, height=100%');
}