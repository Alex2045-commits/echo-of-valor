function Game() {
  this.cellSize = 32;
  this.viewX = 0;
  this.viewY = 0;
  this.canvas = document.getElementById("GameCanvas");
  this.ctx = this.canvas.getContext("2d");
  this.tiles = [];
  this.blocks = [];
  this.player = null;
  this.monster = null;
  this.gravity = 0.4;
  this.keys = {};

   // Contatori per il respawn del mostro
  this.monsterSpawnCount = 1; // Primo mostro già presente
  this.maxMonsters = 4;       // Totale mostri da far apparire
  this.nextMonsterSpawnTime = null;


  // Nuove immagini dei cuori
  this.heart3 = new Image();
  this.heart2 = new Image();
  this.heart1 = new Image();
  this.heart0 = new Image();

  // Immagine per Game Over
  this.gameOverImage = new Image();

  this.resizeCanvas = function () {
    this.canvas.width = window.innerWidth;
    this.canvas.height = window.innerHeight;
  };

  this.resizeCanvas();

  const loadImage = (src) => {
    const img = new Image();
    img.src = src;
    return new Promise((resolve, reject) => {
      img.onload = () => resolve(img);
      img.onerror = reject;
    });
  };

  this.loadAssets = async function (callback) {
    try {
      await Promise.all([
        loadImage("Personaggi_Gioco/Idle.png"),
        loadImage("Personaggi_Gioco/Run.png"),
        loadImage("Personaggi_Gioco/RunBack.png"),
        loadImage("Personaggi_Gioco/Jump.png"),
        loadImage("Personaggi_Gioco/JumpBack.png"),
        loadImage("Personaggi_Gioco/Attack_1.png"),
        loadImage("Personaggi_Gioco/Attack_2.png"),
        loadImage("Personaggi_Gioco/Attack_3.png"),
        loadImage("Personaggi_Gioco/AttackBack_1.png"),
        loadImage("Personaggi_Gioco/AttackBack_2.png"),
        loadImage("Personaggi_Gioco/AttackBack_3.png"),
        loadImage("Personaggi_Gioco/Hurt.png"),
        loadImage("Personaggi_Gioco/Dead.png"),
        loadImage("livello_0.png"),
        loadImage("Primo_Mostro/Idle.png"),
        loadImage("Primo_Mostro/Walk.png"),
        loadImage("Primo_Mostro/Run.png"),
        loadImage("Primo_Mostro/Attack_1.png"),
        loadImage("Primo_Mostro/Attack_2.png"),
        loadImage("Primo_Mostro/Attack_3.png"),
        loadImage("Primo_Mostro/Dead.png"),
        // Caricamento delle immagini dei cuori
        loadImage("CuoriGioco/3cuori.png"),
        loadImage("CuoriGioco/2cuori.png"),
        loadImage("CuoriGioco/1cuore.png"),
        loadImage("CuoriGioco/0cuori.png"),
        // Caricamento dell'immagine di Game Over
        loadImage("img/gameOver.png"),
      ]);

      // Assegnazione delle immagini dei cuori
      this.heart3.src = "CuoriGioco/3cuori.png";
      this.heart2.src = "CuoriGioco/2cuori.png";
      this.heart1.src = "CuoriGioco/1cuore.png";
      this.heart0.src = "CuoriGioco/0cuori.png";

      // Assegnazione dell'immagine di Game Over
      this.gameOverImage.src = "img/gameOver.png";

      this.sprPlayerIdle = new Image(); this.sprPlayerIdle.src = "Personaggi_Gioco/Idle.png";
      this.sprPlayerRun = new Image(); this.sprPlayerRun.src = "Personaggi_Gioco/Run.png";
      this.sprPlayerRunBack = new Image(); this.sprPlayerRunBack.src = "Personaggi_Gioco/RunBack.png";
      this.sprPlayerJump = new Image(); this.sprPlayerJump.src = "Personaggi_Gioco/Jump.png";
      this.sprPlayerJumpBack = new Image(); this.sprPlayerJumpBack.src = "Personaggi_Gioco/JumpBack.png";
      this.sprAttack1 = new Image(); this.sprAttack1.src = "Personaggi_Gioco/Attack_1.png";
      this.sprAttack2 = new Image(); this.sprAttack2.src = "Personaggi_Gioco/Attack_2.png";
      this.sprAttack3 = new Image(); this.sprAttack3.src = "Personaggi_Gioco/Attack_3.png";
      this.sprAttackBack1 = new Image(); this.sprAttackBack1.src = "Personaggi_Gioco/AttackBack_1.png";
      this.sprAttackBack2 = new Image(); this.sprAttackBack2.src = "Personaggi_Gioco/AttackBack_2.png";
      this.sprAttackBack3 = new Image(); this.sprAttackBack3.src = "Personaggi_Gioco/AttackBack_3.png";
      this.sprPlayerHurt = new Image(); this.sprPlayerHurt.src = "Personaggi_Gioco/Hurt.png";
      this.sprPlayerDead = new Image(); this.sprPlayerDead.src = "Personaggi_Gioco/Dead.png";
      this.background1 = new Image(); this.background1.src = "livello_0.png";

      this.sprMonsterIdle = new Image(); this.sprMonsterIdle.src = "Primo_Mostro/Idle.png";
      this.sprMonsterWalk = new Image(); this.sprMonsterWalk.src = "Primo_Mostro/Walk.png";
      this.sprMonsterRun = new Image(); this.sprMonsterRun.src = "Primo_Mostro/Run.png";
      this.sprMonsterAttack1 = new Image(); this.sprMonsterAttack1.src = "Primo_Mostro/Attack_1.png";
      this.sprMonsterAttack2 = new Image(); this.sprMonsterAttack2.src = "Primo_Mostro/Attack_2.png";
      this.sprMonsterAttack3 = new Image(); this.sprMonsterAttack3.src = "Primo_Mostro/Attack_3.png";
      this.sprMonsterDead = new Image(); this.sprMonsterDead.src = "Primo_Mostro/Dead.png";

      this.player = new Player(
        this.sprPlayerIdle,
        this.sprPlayerRun,
        this.sprPlayerRunBack,
        this.sprPlayerJump,
        this.sprPlayerJumpBack,
        this.sprAttack1,
        this.sprAttack2,
        this.sprAttack3,
        this.sprAttackBack1,
        this.sprAttackBack2,
        this.sprAttackBack3,
        this.sprPlayerHurt,
        this.sprPlayerDead
      );

      this.monster = new Mostro(
        this.sprMonsterIdle,
        this.sprMonsterWalk,
        this.sprMonsterRun,
        this.sprMonsterAttack1,
        this.sprMonsterAttack2,
        this.sprMonsterAttack3,
        this.sprMonsterDead
      );

      callback();
    } catch (error) {
      console.error("Error loading images:", error);
    }
  };

  //per far spawnar il mostro di nuovo
  this.spawnNewMonster = function () {
  this.monster = new Mostro(
    this.sprMonsterIdle,
    this.sprMonsterWalk,
    this.sprMonsterRun,
    this.sprMonsterAttack1,
    this.sprMonsterAttack2,
    this.sprMonsterAttack3,
    this.sprMonsterDead
  );
  this.monsterSpawnCount++;
};

  // Funzione per applicare la sfocatura al background
  this.applyBlur = () => {
    this.ctx.filter = 'blur(10px)'; // Aggiungi sfocatura
    this.ctx.drawImage(this.background1, 0, 0, this.canvas.width, this.canvas.height);
    this.ctx.filter = 'none'; // Ripristina il filtro
  };

  this.GameLoop = () => {
    if (this.player) this.player.Update();
    //funzione per il respawn
    if (this.monster) {
  this.monster.Update();
  // Se il mostro è morto e deve essere rimosso
  if (this.monster.shouldRemove && this.monsterSpawnCount < this.maxMonsters) {
    if (!this.nextMonsterSpawnTime) {
      this.nextMonsterSpawnTime = Date.now() + 3000; // Aspetta 3 secondi
    } else if (Date.now() >= this.nextMonsterSpawnTime) {
      this.spawnNewMonster();
      this.nextMonsterSpawnTime = null;
    }
  }
}

    this.Draw();
    window.requestAnimationFrame(this.GameLoop);
  };

  this.Draw = function () {
    this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);

    // Se il gioco è finito, mostra la schermata di Game Over con sfondo sfocato
    if (this.player.isDead) {
      this.applyBlur(); // Applica la sfocatura al background
      this.ctx.drawImage(this.gameOverImage, this.canvas.width / 2 - this.gameOverImage.width / 2, this.canvas.height / 2 - this.gameOverImage.height / 2);
      
      // Ritorna alla pagina di inizio dopo 5 secondi
      setTimeout(() => {
        window.location.href = "../index.html"; // Questo ricarica la pagina di gioco
      }, 5000);

      return;
    }

    // Se il gioco non è finito, disegna normalmente il background
    this.ctx.drawImage(this.background1, 0, 0, this.canvas.width, this.canvas.height);

    if (this.player) this.player.Draw(this.ctx);
    if (this.monster) this.monster.Draw(this.ctx);

    // Disegna il cuore in alto a sinistra in base alla salute del giocatore
    if (this.player) {
      const heartSize = 475;
      const border = -100;
      const gundam = -150;

      let heartImage;

      // Scegli l'immagine in base alla salute del giocatore
      if (this.player.health === 3) {
        heartImage = this.heart3;
      } else if (this.player.health === 2) {
        heartImage = this.heart2;
      } else if (this.player.health === 1) {
        heartImage = this.heart1;
      } else {
        heartImage = this.heart0;
      }

      // Posizionamento cuore in alto a sinistra
      this.ctx.drawImage(heartImage, border, gundam, heartSize, heartSize);
    }
  };

  this.hidePreLoader = function () {
    const preLoader = document.getElementById('preLoader');
    if (preLoader) {
      setTimeout(() => {
        preLoader.classList.add('hidden');
      }, 500);
    }
  };

  this.StartGame = function () {
    this.loadAssets(() => {
      this.hidePreLoader();
      this.GameLoop();
    });
  };

  let attackCounter = 0;
  window.addEventListener('click', () => {
    if (this.player) {
      attackCounter = (attackCounter + 1) % 3;
      this.player.handleMouseClick(attackCounter);
    }
  });

  window.addEventListener("keydown", (e) => {
    this.keys[e.key] = true;
  });

  window.addEventListener("keyup", (e) => {
    this.keys[e.key] = false;
  });
}

let game = new Game();
game.StartGame();
