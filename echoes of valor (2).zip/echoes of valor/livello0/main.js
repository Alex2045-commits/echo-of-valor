function Game() {
  this.cellSize = 32;
  this.viewX = 0;
  this.viewY = 0;
  this.canvas = document.getElementById("GameCanvas");
  this.ctx = this.canvas.getContext("2d");
  this.tiles = [];
  this.blocks = [];
  this.player = null;
  this.monster = null;
  this.gravity = 0.4;
  this.keys = {};

  // Nuove immagini cuori
  this.heartFull = new Image();
  this.heartEmpty = new Image();
  this.heartDead = new Image();

  this.resizeCanvas = function () {
    this.canvas.width = window.innerWidth;
    this.canvas.height = window.innerHeight;
  };

  this.resizeCanvas();

  const loadImage = (src) => {
    const img = new Image();
    img.src = src;
    return new Promise((resolve, reject) => {
      img.onload = () => resolve(img);
      img.onerror = reject;
    });
  };

  this.loadAssets = async function (callback) {
    try {
      await Promise.all([
        loadImage("Personaggi_Gioco/Idle.png"),
        loadImage("Personaggi_Gioco/Run.png"),
        loadImage("Personaggi_Gioco/RunBack.png"),
        loadImage("Personaggi_Gioco/Jump.png"),
        loadImage("Personaggi_Gioco/JumpBack.png"),
        loadImage("Personaggi_Gioco/Attack_1.png"),
        loadImage("Personaggi_Gioco/Attack_2.png"),
        loadImage("Personaggi_Gioco/Attack_3.png"),
        loadImage("Personaggi_Gioco/AttackBack_1.png"),
        loadImage("Personaggi_Gioco/AttackBack_2.png"),
        loadImage("Personaggi_Gioco/AttackBack_3.png"),
        loadImage("Personaggi_Gioco/Hurt.png"),
        loadImage("Personaggi_Gioco/Dead.png"),
        loadImage("livello_0.png"),
        loadImage("Primo_Mostro/Idle.png"),
        loadImage("Primo_Mostro/Walk.png"),
        loadImage("Primo_Mostro/Run.png"),
        loadImage("Primo_Mostro/Attack_1.png"),
        loadImage("Primo_Mostro/Attack_2.png"),
        loadImage("Primo_Mostro/Attack_3.png"),
        loadImage("Primo_Mostro/Dead.png"),
        // Aggiunta immagini cuori
        loadImage("img/heart_full.png"),
        loadImage("img/heart_empty.png"),
        loadImage("img/heart_dead.png"),
      ]);

      this.sprPlayerIdle = new Image(); this.sprPlayerIdle.src = "Personaggi_Gioco/Idle.png";
      this.sprPlayerRun = new Image(); this.sprPlayerRun.src = "Personaggi_Gioco/Run.png";
      this.sprPlayerRunBack = new Image(); this.sprPlayerRunBack.src = "Personaggi_Gioco/RunBack.png";
      this.sprPlayerJump = new Image(); this.sprPlayerJump.src = "Personaggi_Gioco/Jump.png";
      this.sprPlayerJumpBack = new Image(); this.sprPlayerJumpBack.src = "Personaggi_Gioco/JumpBack.png";
      this.sprAttack1 = new Image(); this.sprAttack1.src = "Personaggi_Gioco/Attack_1.png";
      this.sprAttack2 = new Image(); this.sprAttack2.src = "Personaggi_Gioco/Attack_2.png";
      this.sprAttack3 = new Image(); this.sprAttack3.src = "Personaggi_Gioco/Attack_3.png";
      this.sprAttackBack1 = new Image(); this.sprAttackBack1.src = "Personaggi_Gioco/AttackBack_1.png";
      this.sprAttackBack2 = new Image(); this.sprAttackBack2.src = "Personaggi_Gioco/AttackBack_2.png";
      this.sprAttackBack3 = new Image(); this.sprAttackBack3.src = "Personaggi_Gioco/AttackBack_3.png";
      this.sprPlayerHurt = new Image(); this.sprPlayerHurt.src = "Personaggi_Gioco/Hurt.png";
      this.sprPlayerDead = new Image(); this.sprPlayerDead.src = "Personaggi_Gioco/Dead.png";
      this.background1 = new Image(); this.background1.src = "livello_0.png";

      this.sprMonsterIdle = new Image(); this.sprMonsterIdle.src = "Primo_Mostro/Idle.png";
      this.sprMonsterWalk = new Image(); this.sprMonsterWalk.src = "Primo_Mostro/Walk.png";
      this.sprMonsterRun = new Image(); this.sprMonsterRun.src = "Primo_Mostro/Run.png";
      this.sprMonsterAttack1 = new Image(); this.sprMonsterAttack1.src = "Primo_Mostro/Attack_1.png";
      this.sprMonsterAttack2 = new Image(); this.sprMonsterAttack2.src = "Primo_Mostro/Attack_2.png";
      this.sprMonsterAttack3 = new Image(); this.sprMonsterAttack3.src = "Primo_Mostro/Attack_3.png";
      this.sprMonsterDead = new Image(); this.sprMonsterDead.src = "Primo_Mostro/Dead.png";

      this.heartFull.src = "img/heart_full.png";
      this.heartEmpty.src = "img/heart_empty.png";
      this.heartDead.src = "img/heart_dead.png";

      this.player = new Player(
        this.sprPlayerIdle,
        this.sprPlayerRun,
        this.sprPlayerRunBack,
        this.sprPlayerJump,
        this.sprPlayerJumpBack,
        this.sprAttack1,
        this.sprAttack2,
        this.sprAttack3,
        this.sprAttackBack1,
        this.sprAttackBack2,
        this.sprAttackBack3,
        this.sprPlayerHurt,
        this.sprPlayerDead
      );

      this.monster = new Mostro(
        this.sprMonsterIdle,
        this.sprMonsterWalk,
        this.sprMonsterRun,
        this.sprMonsterAttack1,
        this.sprMonsterAttack2,
        this.sprMonsterAttack3,
        this.sprMonsterDead
      );

      callback();
    } catch (error) {
      console.error("Error loading images:", error);
    }
  };

  this.GameLoop = () => {
    if (this.player) this.player.Update();
    if (this.monster) this.monster.Update();
    this.Draw();
    window.requestAnimationFrame(this.GameLoop);
  };

  this.Draw = function () {
    this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
    this.ctx.drawImage(this.background1, 0, 0, this.canvas.width, this.canvas.height);

    if (this.player) this.player.Draw(this.ctx);
    if (this.monster) this.monster.Draw(this.ctx);

    // Disegna i cuori in alto a destra con logica "spegnimento da destra a sinistra"
    if (this.player) {
      const heartSize = 40;
      const padding = 10;
      const maxHealth = 3;
      const currentHealth = this.player.health;

      for (let i = 0; i < maxHealth; i++) {
        let heartImage;

        // Se il giocatore è morto, tutti cuori "dead"
        if (currentHealth === 0) {
          heartImage = this.heartDead;
        } else {
          // Cuori si spengono da destra verso sinistra
          // i = indice cuore da sinistra (0..2)
          // il cuore da spegnere è partendo da destra
          // se i >= currentHealth --> cuore vuoto (empty)
          // altrimenti cuore pieno (full)
          if (i >= currentHealth) {
            heartImage = this.heartEmpty;
          } else {
            heartImage = this.heartFull;
          }
        }

        this.ctx.drawImage(heartImage, this.canvas.width - (padding + (i + 1) * (heartSize + padding)), padding, heartSize, heartSize);
      }
    }
  };

  this.hidePreLoader = function () {
    const preLoader = document.getElementById('preLoader');
    if (preLoader) {
      setTimeout(() => {
        preLoader.classList.add('hidden');
      }, 500);
    }
  };

  this.StartGame = function () {
    this.loadAssets(() => {
      this.hidePreLoader();
      this.GameLoop();
    });
  };

  let attackCounter = 0;
  window.addEventListener('click', () => {
    if (this.player) {
      attackCounter = (attackCounter + 1) % 3;
      this.player.handleMouseClick(attackCounter);
    }
  });

  window.addEventListener("keydown", (e) => {
    this.keys[e.key] = true;
  });

  window.addEventListener("keyup", (e) => {
    this.keys[e.key] = false;
  });
}

let game = new Game();
game.StartGame();
